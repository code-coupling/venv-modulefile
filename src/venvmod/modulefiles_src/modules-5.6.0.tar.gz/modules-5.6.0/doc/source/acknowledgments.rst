.. _acknowledgments:

Acknowledgments
================

We would like to express our gratitude to `CEA`_ for the resources and funding
provided to the project over the recent years.

We acknowledge all the contributors and users of the Modules community who
participate to the quality of the project with valuable feedback and code
improvement.

The following people have notably contributed to Modules and Modules would not
be what it is without their contributions:

* R.K. Owen
* Kent Mein
* Mark Lakata
* Harlan Stenn
* Leo Butler
* Robert Minsk
* Jens Hamisch
* Peter W. Osel
* John L. Furlan

.. _CEA: https://www.cea.fr/english
