.. _devel:

Developer HowTos
================

Developer guides to implement new command, option, etc or draft a new release
of Modules.

..  toctree::
    :maxdepth: 1
    :glob:

    devel/*
