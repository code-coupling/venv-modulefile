This directory has symlinks for flavours
