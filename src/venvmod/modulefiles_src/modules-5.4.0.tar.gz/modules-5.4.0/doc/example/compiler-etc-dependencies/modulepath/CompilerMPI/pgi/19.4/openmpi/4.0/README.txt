Need a dummy directory here to prevent the openmpi/4.0 modulefile
in Compiler/pgi/19.4 from complaining
